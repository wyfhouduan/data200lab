# data200_datascienceresumes
A collection of data science resumes for the DATA-200 course. 

Inspired by Eric Scott's data science resume sample and Yihui's **pagedown** package. Thanks to you both! 
